﻿# EPPlus.System.Drawing
Adds support for Drawing operations using System.Drawing.Common for EPPlus. Used for operations like imaging and text measure.