﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class AdminPanel : Form
    {
        TextBox[] objectInfo;
        TextBox[] managerInfo;
        string photo;
        public AdminPanel()
        {
            InitializeComponent();
            objectInfo = new TextBox[] { objectBox1, objectBox2, objectBox3 };
            managerInfo = new TextBox[] { managerBox1, managerBox2, managerBox3, managerBox4, managerBox5, managerBox6 };
            DataBase.DataView(dataGridView1, "Объект");
            DataBase.DataView(dataGridView2, "Сотрудник");
        }

        private void AdminPanel_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Title = "Выбрать изображение";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.BackgroundImage = Image.FromFile(openFile.FileName);
                photo = "image\\" + Path.GetFileName(openFile.FileName);
                string imgPath = Path.Combine(Environment.CurrentDirectory, photo);
                    File.Copy(openFile.FileName, imgPath);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.AddObject(objectInfo[0].Text, int.Parse(objectInfo[1].Text), objectInfo[2].Text, photo);

                MessageBox.Show("Данные были успешно добавлены.");
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            DataBase.DataView(dataGridView1, "Объект");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Authorization form1 = new Authorization();
            form1.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.AddManager(managerInfo[0].Text, managerInfo[1].Text, managerInfo[2].Text, managerInfo[3].Text, managerInfo[4].Text, managerInfo[5].Text);

                MessageBox.Show("Данные были успешно добавлены.");
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
            DataBase.DataView(dataGridView2, "Сотрудник");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.DeleteObject(dataGridView1);
            }
            catch
            {
                MessageBox.Show("Удаление невозможно.");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.DeleteManager(dataGridView2);
            }

            catch 
            {
                MessageBox.Show("Удаление невозможно.");
            }
        }
    }
}
