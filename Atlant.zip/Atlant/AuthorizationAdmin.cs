﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class AuthorizationAdmin : Form
    {
        private SqlConnection connection;
        public AuthorizationAdmin()
        {
            InitializeComponent();
            string connectionString = "Server=RIINNOTEBOOK\\SQLEXPRESS01;Database=Atlant;Encrypt=False;Trusted_Connection=True;";
            connection = new SqlConnection(connectionString);
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Получение логина и пароля из полей ввода
                string login = loginText.Text.Trim();
                string password = passText.Text.Trim();

                // Проверка введенных данных на соответствие в базе данных
                string query = "SELECT COUNT(*) FROM Администратор WHERE Логин=@Логин AND Пароль=@Пароль";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Логин", login);
                command.Parameters.AddWithValue("@Пароль", password);
                connection.Open();
                int count = (int)command.ExecuteScalar();
                connection.Close();
                if (count > 0)
                {
                    MessageBox.Show("Успешная авторизация!");
                    AdminPanel mainForm = new AdminPanel();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    // Ошибка авторизации
                    MessageBox.Show("Неверный логин или пароль!");
                }
            }
            catch
            {
                MessageBox.Show("Отсутствует подключение к базе данных!");
            }
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Authorization form1 = new Authorization();
            form1.Show();
            this.Hide();
        }

        private void AuthorizationAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}
