﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class Authorization : Form
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AuthorizationAdmin form2 = new AuthorizationAdmin();
            form2.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AuthorizationManager form1 = new AuthorizationManager();
            form1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AuthorizationZakaz form3 = new AuthorizationZakaz();
            form3.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GuestMain guest = new GuestMain();
            guest.Show();
            this.Hide();
        }

        private void Authorization_Load(object sender, EventArgs e)
        {

        }
    }
}
