﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static System.Windows.Forms.Label;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    internal class DataBase
    {
        const string connectionString = "Server=DESKTOP-VF772TM;Database=Atlant;Encrypt=False;Trusted_Connection=True;";
        public static void GetInfoObject(List<Object> objects)
        {
            try
            {
                string phoneRequest = $"SELECT * FROM Объект";
                SqlConnection conn = new SqlConnection(connectionString);
                conn.Open();
                SqlCommand sqlCommand = new SqlCommand(phoneRequest, conn);
                SqlDataReader reader = sqlCommand.ExecuteReader();
                while (reader.Read())
                    objects.Add(new Object((string)reader.GetValue(1), (int)reader.GetValue(2), (string)reader.GetValue(3), (string)reader.GetValue(4)));
                conn.Close();
            }
            catch 
            {
                MessageBox.Show("Отсутствует подключение к базе данных!");            
            }
        }

        public static void GetZakazObject(DataGridView dataGridView1, System.Windows.Forms.Label zakazObject1, System.Windows.Forms.Label label13, System.Windows.Forms.Label label14, System.Windows.Forms.Label zakazObject2, System.Windows.Forms.Label zakazObject3, System.Windows.Forms.Label zakazObject4, System.Windows.Forms.Label zakazObject5, System.Windows.Forms.Label zakazObject6, System.Windows.Forms.Label zakazObject7, System.Windows.Forms.Label zakazObject8, PictureBox pictureBox1)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                int managerID = Convert.ToInt32(selectedRow.Cells["ID_менеджера"].Value);
                int objectID = Convert.ToInt32(selectedRow.Cells["ID_объекта"].Value);
                int statusID = Convert.ToInt32(selectedRow.Cells["ID_статуса"].Value);
                int zakazID = Convert.ToInt32(selectedRow.Cells["ID_заказчика"].Value);
                string imageUrl = "";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query7 = "SELECT Фото_статуса FROM Статус WHERE ID = @ID_статуса";
                    using (SqlCommand command = new SqlCommand(query7, connection))
                    {
                        command.Parameters.AddWithValue("@ID_статуса", selectedRow.Cells["ID_статуса"].Value);
                        imageUrl = command.ExecuteScalar()?.ToString();
                    }
                }

                pictureBox1.ImageLocation = imageUrl;

                string query = "SELECT Фамилия FROM Сотрудник WHERE ID = @ID_менеджера";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ID_менеджера", managerID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    zakazObject1.Text = fieldValue;
                }

                string query2 = "SELECT Имя FROM Сотрудник WHERE ID = @ID_менеджера";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query2, connection);
                    command.Parameters.AddWithValue("@ID_менеджера", managerID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    label13.Text = fieldValue;
                }

                string query3 = "SELECT Отчество FROM Сотрудник WHERE ID = @ID_менеджера";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query3, connection);
                    command.Parameters.AddWithValue("@ID_менеджера", managerID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    label14.Text = fieldValue;
                }

                string query4 = "SELECT Тип_объекта FROM Объект WHERE ID = @ID_объекта";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query4, connection);
                    command.Parameters.AddWithValue("@ID_объекта", objectID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    zakazObject2.Text = fieldValue;
                }

                string query5 = "SELECT Описание FROM Статус WHERE ID = @ID_статуса";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query5, connection);
                    command.Parameters.AddWithValue("@ID_статуса", statusID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    zakazObject3.Text = fieldValue;
                }

                string query6 = "SELECT Имя FROM Заказчик WHERE ID = @ID_заказчика";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query6, connection);
                    command.Parameters.AddWithValue("@ID_заказчика", zakazID);
                    connection.Open();
                    string fieldValue = command.ExecuteScalar().ToString();
                    zakazObject4.Text = fieldValue;
                }

                string fieldValue5 = selectedRow.Cells["Стоимость"].Value.ToString();
                zakazObject5.Text = fieldValue5;

                string fieldValue6 = selectedRow.Cells["Дата_начала"].Value.ToString();
                zakazObject6.Text = fieldValue6;

                string fieldValue7 = selectedRow.Cells["Дата_конца"].Value.ToString();
                zakazObject7.Text = fieldValue7;

                string fieldValue8 = selectedRow.Cells["Адрес"].Value.ToString();
                zakazObject8.Text = fieldValue8;
            }
        }
        /// <summary>
        /// Добавление объектов в базу данных
        /// </summary>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <param name="photo"></param>
        
        public static void AddOrder(int menID, int objID, int statusID, int ordererID, int price, DateTime dateStart, DateTime dateEnd, string address)
        {
            string addRequest = $"INSERT INTO dbo.Заказ VALUES ({menID}, {objID},{statusID},{ordererID}, {price}, '{dateStart}', '{dateEnd}', '{address}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteOrder(DataGridView dataGridView1)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand command = new SqlCommand("DELETE FROM Заказ WHERE ID = @ID", conn);

            int rowIndex = dataGridView1.SelectedCells[0].RowIndex;
            string primaryKeyValue = dataGridView1.Rows[rowIndex].Cells["ID"].Value.ToString();
            command.Parameters.AddWithValue("@ID", primaryKeyValue);

            command.ExecuteNonQuery();

            dataGridView1.Rows.RemoveAt(rowIndex);

            conn.Close();
        }
        public static void AddOrderer(string surname, string name, string father, string number, string login, string password)
        {
            string addRequest = $"INSERT INTO dbo.Заказчик VALUES ('{surname}','{name}','{father}','{number}','{login}','{password}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteOrderer (DataGridView dataGridView2)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand command = new SqlCommand("DELETE FROM Заказчик WHERE ID = @ID", conn);

            int rowIndex = dataGridView2.SelectedCells[0].RowIndex;
            string primaryKeyValue = dataGridView2.Rows[rowIndex].Cells["ID"].Value.ToString();
            command.Parameters.AddWithValue("@ID", primaryKeyValue);

            command.ExecuteNonQuery();

            dataGridView2.Rows.RemoveAt(rowIndex);

            conn.Close();
        }
        public static void AddStatus(DateTime date, string desc, string photo)
        {
            string addRequest = $"INSERT INTO dbo.Статус VALUES ('{date}','{desc}','{photo}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteStatus(DataGridView dataGridView3)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand command = new SqlCommand("DELETE FROM Статус WHERE ID = @ID", conn);

            int rowIndex = dataGridView3.SelectedCells[0].RowIndex;
            string primaryKeyValue = dataGridView3.Rows[rowIndex].Cells["ID"].Value.ToString();
            command.Parameters.AddWithValue("@ID", primaryKeyValue);

            command.ExecuteNonQuery();

            dataGridView3.Rows.RemoveAt(rowIndex);

            conn.Close();
        }

        public static void AddManager(string surname, string name, string father, string login, string password, string number)
        {
            string addRequest = $"INSERT INTO dbo.Сотрудник VALUES ('{surname}','{name}','{father}','{login}','{password}','{number}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteManager(DataGridView dataGridView2)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand command = new SqlCommand("DELETE FROM Сотрудник WHERE ID = @ID", conn);

            int rowIndex = dataGridView2.SelectedCells[0].RowIndex;
            string primaryKeyValue = dataGridView2.Rows[rowIndex].Cells["ID"].Value.ToString();
            command.Parameters.AddWithValue("@ID", primaryKeyValue);

            command.ExecuteNonQuery();

            dataGridView2.Rows.RemoveAt(rowIndex);

            conn.Close();
        }

        public static void AddObject(string type, int size, string opisanie, string photo)
        {
            string addRequest = $"INSERT INTO dbo.Объект VALUES ('{type}',{size},'{opisanie}','{photo}');";
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand sqlCommand = new SqlCommand(addRequest, conn);
            sqlCommand.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteObject(DataGridView dataGridView1)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();

            SqlCommand command = new SqlCommand("DELETE FROM Объект WHERE ID = @ID", conn);

            int rowIndex = dataGridView1.SelectedCells[0].RowIndex;
            string primaryKeyValue = dataGridView1.Rows[rowIndex].Cells["ID"].Value.ToString();
            command.Parameters.AddWithValue("@ID", primaryKeyValue);

            command.ExecuteNonQuery();

            dataGridView1.Rows.RemoveAt(rowIndex);

            conn.Close();
        }

        public static void DataView(DataGridView data, string nameTable)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            string cmd = $"SELECT * FROM {nameTable}";
            SqlCommand createCommand = new SqlCommand(cmd, conn);
            createCommand.ExecuteNonQuery();

            SqlDataAdapter dataAdp = new SqlDataAdapter(createCommand);
            DataTable dt = new DataTable($"{nameTable}");
            dataAdp.Fill(dt);
            data.DataSource = dt.DefaultView;
            conn.Close();
        }

        public static void ZakazView (DataGridView data)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            data.Columns.Add("ID", "ID");
            data.Columns.Add("ID_менеджера", "ID_менеджера");
            data.Columns.Add("ID_объекта", "ID_объекта");
            data.Columns.Add("ID_статуса", "ID_статуса");
            data.Columns.Add("ID_заказчика", "ID_заказчика");
            data.Columns.Add("Стоимость", "Стоимость");
            data.Columns.Add("Дата_начала", "Дата_начала");
            data.Columns.Add("Дата_конца", "Дата_конца");
            data.Columns.Add("Адрес", "Адрес");
        }

        public static void ZakazInfo()
        {

        }
    }
}
