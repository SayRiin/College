﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using OfficeOpenXml;
using System.Reflection;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Data.SqlClient;
using System.Linq;
using System.Collections.Generic;

namespace Atlant
{
    public partial class ManagerPanel : Form
    {
        TextBox[] ordersInfo;
        TextBox[] ordererInfo;
        TextBox[] statusInfo;
        string photo;

        string connectionString = "Server=DESKTOP-VF772TM;Database=Atlant;Encrypt=False;Trusted_Connection=True;";
        public ManagerPanel()
        {
            InitializeComponent();
            ordersInfo = new TextBox[] { orderBox1, orderBox2, orderBox3, orderBox4, orderBox5, orderBox6 };
            ordererInfo = new TextBox[] { userBox1, userBox2, userBox3, userBox4, userBox5, userBox6 };
            statusInfo = new TextBox[] { statusBox1 };
            DataBase.DataView(dataGridView1, "Заказ");
            DataBase.DataView(dataGridView2, "Заказчик");
            DataBase.DataView(dataGridView3, "Статус");
        }

        private void ManagerPanel_Load(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.AddOrder(int.Parse(ordersInfo[0].Text), int.Parse(ordersInfo[1].Text), int.Parse(ordersInfo[2].Text), int.Parse(ordersInfo[3].Text), int.Parse(ordersInfo[4].Text), dateTimePicker2.Value, dateTimePicker3.Value, ordersInfo[5].Text);

                MessageBox.Show("Данные были успешно добавлены.");
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.AddOrderer(ordererInfo[0].Text, ordererInfo[1].Text, ordererInfo[2].Text, ordererInfo[3].Text, ordererInfo[4].Text, ordererInfo[5].Text);

                MessageBox.Show("Данные были успешно добавлены.");
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные.");
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Title = "Выбрать изображение";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.BackgroundImage = Image.FromFile(openFile.FileName);
                photo = "imageStatus\\" + Path.GetFileName(openFile.FileName);
                string imgPath = Path.Combine(Environment.CurrentDirectory, photo);
                File.Copy(openFile.FileName, imgPath);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.AddStatus(dateTimePicker1.Value, statusInfo[0].Text, photo);

                MessageBox.Show("Данные были успешно добавлены.");
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректные данные.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            DataBase.DataView(dataGridView1, "Заказ");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = null;
            DataBase.DataView(dataGridView2, "Заказчик");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView3.DataSource = null;
            DataBase.DataView(dataGridView3, "Статус");
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Authorization form1 = new Authorization();
            form1.Show();
            this.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            object oMissing = Missing.Value; //Создание файла
            System.Object oEndOfDoc = "\\endofdoc";
            Microsoft.Office.Interop.Word._Application appw = new Microsoft.Office.Interop.Word.Application(); //Создание ИМЕННО документа
            Microsoft.Office.Interop.Word._Document dw; //Создание страницы
            appw.Visible = true; //Отображение

            dw = appw.Documents.Add(typeof(Program).Assembly.Location + "/../../../" + "Шаблон.docx", Visible: true); //Копирование данных из файла
            dw.Bookmarks["ID"].Range.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            dw.Bookmarks["Дата"].Range.Text = ((DateTime)dataGridView1.CurrentRow.Cells[6].Value).ToShortDateString();
            dw.Bookmarks["Дата_начала"].Range.Text = ((DateTime)dataGridView1.CurrentRow.Cells[6].Value).ToShortDateString();
            dw.Bookmarks["Дата_конца"].Range.Text = ((DateTime)dataGridView1.CurrentRow.Cells[7].Value).ToShortDateString();
            dw.Bookmarks["Адрес"].Range.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            dw.Bookmarks["Стоимость"].Range.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();//Берёт данные из таблицы

            //string b = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            //pictureBox3.ImageLocation = b;
            //dw.Bookmarks["photo"].Range.Text = b;

            SqlConnection conn = new SqlConnection(@"Server=RIINNOTEBOOK\SQLEXPRESS01;Database=Atlant;Trusted_Connection=true");
            conn.Open();

            SqlCommand Commu = conn.CreateCommand();
            Commu.CommandText = "Select Фамилия From Заказчик where (ID = " + dataGridView1.CurrentRow.Cells[4].Value.ToString() + ")";
            dw.Bookmarks["Фамилия"].Range.Text = Commu.ExecuteScalar().ToString();

            SqlCommand Comm = conn.CreateCommand();
            Comm.CommandText = "Select Имя From Заказчик where (ID = " + dataGridView1.CurrentRow.Cells[4].Value.ToString() + ")";
            dw.Bookmarks["Имя"].Range.Text = Comm.ExecuteScalar().ToString();

            SqlCommand Commi = conn.CreateCommand();
            Commi.CommandText = "Select Отчество From Заказчик where (ID = " + dataGridView1.CurrentRow.Cells[4].Value.ToString() + ")";
            dw.Bookmarks["Отчество"].Range.Text = Commi.ExecuteScalar().ToString();

            SqlCommand Comma = conn.CreateCommand();
            Comma.CommandText = "Select Фамилия From Сотрудник where (ID = " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + ")";
            dw.Bookmarks["Фамилия_мен"].Range.Text = Comma.ExecuteScalar().ToString();

            SqlCommand Commn = conn.CreateCommand();
            Commn.CommandText = "Select Имя From Сотрудник where (ID = " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + ")";
            dw.Bookmarks["Имя_мен"].Range.Text = Commn.ExecuteScalar().ToString();

            SqlCommand Commo = conn.CreateCommand();
            Commo.CommandText = "Select Отчество From Сотрудник where (ID = " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + ")";
            dw.Bookmarks["Отчество_мен"].Range.Text = Commo.ExecuteScalar().ToString();

            SqlCommand Commnum = conn.CreateCommand();
            Commnum.CommandText = "Select Номер_телефона From Сотрудник where (ID = " + dataGridView1.CurrentRow.Cells[1].Value.ToString() + ")";
            dw.Bookmarks["Номер"].Range.Text = Commnum.ExecuteScalar().ToString();

            SqlCommand Commobj = conn.CreateCommand();
            Commobj.CommandText = "Select Тип_объекта From Объект where (ID = " + dataGridView1.CurrentRow.Cells[2].Value.ToString() + ")";
            dw.Bookmarks["Объект"].Range.Text = Commobj.ExecuteScalar().ToString();

            SqlCommand Commst = conn.CreateCommand();
            Commst.CommandText = "Select Описание From Статус where (ID = " + dataGridView1.CurrentRow.Cells[3].Value.ToString() + ")";
            dw.Bookmarks["Статус"].Range.Text = Commst.ExecuteScalar().ToString();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string connectionString2 = "Data Source=RIINNOTEBOOK\\SQLEXPRESS01;Initial Catalog=Atlant;Integrated Security = True";


            SqlConnection connection = new SqlConnection(connectionString2);
            connection.Open();
            string queryString = "delete FROM Заказ WHERE ID = 4";
            SqlCommand command = new SqlCommand(queryString, connection);
            command.ExecuteNonQuery();
            connection.Close();

        }

       

        private void button9_Click(object sender, EventArgs e)
        {
          
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel Files|*.xlsx";
            saveFileDialog.Title = "Save an Excel File";
            saveFileDialog.ShowDialog();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            if (saveFileDialog.FileName != "")
            {
                using (ExcelPackage excelPackage = new ExcelPackage())
                {
                    ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Sheet1");

                    // Записываем заголовки столбцов
                    for (int i = 1; i <= dataGridView1.Columns.Count; i++)
                    {
                        worksheet.Cells[1, i].Value = dataGridView1.Columns[i - 1].HeaderText;
                    }

                    // Записываем данные из DataGridView
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        for (int j = 0; j < dataGridView1.Columns.Count; j++)
                        {
                            worksheet.Cells[i + 2, j + 1].Value = dataGridView1.Rows[i].Cells[j].Value;
                        }
                    }

                    // Сохраняем файл
                    excelPackage.SaveAs(new System.IO.FileInfo(saveFileDialog.FileName));
                }

                MessageBox.Show("Файл успешно сохранен!");
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.DeleteStatus(dataGridView3);
            }
            catch
            {
                MessageBox.Show("Удаление невозможно.");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                DataBase.DeleteOrderer(dataGridView2);
            }
            catch
            {
                MessageBox.Show("Удаление невозможно.");
            }
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            try
            {
                DataBase.DeleteOrder(dataGridView1);
            }
            catch
            {
                MessageBox.Show("Удаление невозможно.");
            }
        }
    }
    }
