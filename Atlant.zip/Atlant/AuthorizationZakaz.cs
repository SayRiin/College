﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class AuthorizationZakaz : Form
    {
        private SqlConnection connection;
        public AuthorizationZakaz()
        {
            InitializeComponent();
            string connectionString = "Server=DESKTOP-VF772TM;Database=Atlant;Encrypt=False;Trusted_Connection=True;";
            connection = new SqlConnection(connectionString);
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Получение логина и пароля из полей ввода
                string login = loginText.Text.Trim();
                string password = passText.Text.Trim();

                // Проверка введенных данных на соответствие в базе данных
                string query = "SELECT COUNT(*) FROM Заказчик WHERE Логин=@Логин AND Пароль=@Пароль";
                string query2 = "SELECT ID FROM Заказчик WHERE Логин=@Логин AND Пароль=@Пароль";
                SqlCommand command = new SqlCommand(query, connection);
                SqlCommand command2 = new SqlCommand(query2, connection);
                command.Parameters.AddWithValue("@Логин", login);
                command.Parameters.AddWithValue("@Пароль", password);
            command2.Parameters.AddWithValue("@Логин", login);
            command2.Parameters.AddWithValue("@Пароль", password);
            connection.Open();
                int count = (int)command.ExecuteScalar();
            connection.Close();
            connection.Open();
            //SqlDataReader read = command2.ExecuteReader();
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            adapter.SelectCommand = command2;
            adapter.Fill(table);
            //while (read.Read())
            //{
                Prosmotr.ID = Convert.ToInt32(table.Rows[0].ItemArray[0]);
            //}
            if (count > 0)
                {
                    MessageBox.Show("Успешная авторизация!");
                    Prosmotr.login = login;    
                    Prosmotr mainForm = new Prosmotr();
                    mainForm.Show();
                    this.Hide();
                }
                else
                {
                    // Ошибка авторизации
                    MessageBox.Show("Неверный логин или пароль!");
                }
            connection.Close();
        }
            catch
            {
                MessageBox.Show("Отсутствует подключение к базе данных!");
            }
}

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Authorization form1 = new Authorization();
            form1.Show();
            this.Hide();
        }

        private void AuthorizationZakaz_Load(object sender, EventArgs e)
        {

        }
    }
}
