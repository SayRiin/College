﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace Atlant
{
    public partial class GuestMain : Form
    {
        System.Windows.Forms.Label[] InfoObject;
        List<Object> objects = new List<Object>();
        int index = 0;
        public GuestMain()
        {
            InitializeComponent();
            DataBase.GetInfoObject(objects);
            InfoObject = new System.Windows.Forms.Label[] { ObjectItem1, ObjectItem2, ObjectItem3 };
            FillInfo(objects, 0);
        }
        private void GuestMain_Load(object sender, EventArgs e)
        {

        }

        private void FillInfo(List<Object> objects, int index)
        {
            try
            {
                int i = 0;
                FieldInfo[] items = objects[index].GetType().GetFields(BindingFlags.NonPublic | BindingFlags.Instance);
                foreach (FieldInfo item in items)
                {
                    if (i != items.Length - 1)
                    {
                        InfoObject[i].Text = item.GetValue(objects[index]).ToString();
                        i++;
                    }
                    else
                        ObjectImage.BackgroundImage = Image.FromFile((Environment.CurrentDirectory + '\\' + item.GetValue(objects[index]).ToString()));
                }
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (index != objects.Count - 1)
                FillInfo(objects, ++index);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (index != 0)
                FillInfo(objects, --index);
        }

        private void sravnit_Click(object sender, EventArgs e)
        {
            Authorization form1 = new Authorization();
            form1.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Spravka form = new Spravka();
            form.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            About form = new About();
            form.Show();
            this.Hide();
        }

        private void ObjectItem1_Click(object sender, EventArgs e)
        {

        }
    }
}
