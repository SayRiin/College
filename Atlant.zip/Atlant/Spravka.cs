﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class Spravka : Form
    {
        public Spravka()
        {
            InitializeComponent();
        }

        private void nazad_Click(object sender, EventArgs e)
        {
            GuestMain form = new GuestMain();
            form.Show();
            this.Hide();
        }
    }
}
