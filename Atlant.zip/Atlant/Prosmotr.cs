﻿using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atlant
{
    public partial class Prosmotr : Form
    {
        
        private SqlConnection connection;
        public static string login;
        public static int ID;
        const string connectionString = "Server=RIINNOTEBOOK\\SQLEXPRESS01;Database=Atlant;Encrypt=False;Trusted_Connection=True;";

        public Prosmotr()
        {
            InitializeComponent();
            dataGridView1.SelectionChanged += dataGridView_SelectionChanged;
            connection = new SqlConnection(connectionString);

            connection.Open();
            
            SqlCommand command = new SqlCommand("SELECT Имя FROM Заказчик WHERE Логин = @Логин", connection);
            command.Parameters.AddWithValue("@Логин", login);

            SqlCommand command2 = new SqlCommand("SELECT * FROM Заказ WHERE ID_заказчика = @ID_заказчика", connection);
            command2.Parameters.AddWithValue("@ID_заказчика", ID);

            string userName = command.ExecuteScalar().ToString();
            SqlDataReader read = command2.ExecuteReader();
            DataBase.ZakazView(dataGridView1);
            while (read.Read())
            {
                dataGridView1.Rows.Add(read.GetInt32(0), read.GetInt32(1), read.GetInt32(2), read.GetInt32(3), read.GetInt32(4), read.GetString(5), read.GetDateTime(6), read.GetDateTime(7), read.GetString(8));
            }

            connection.Close();

            zakazName.Text = userName;
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            Authorization form = new Authorization();
            form.Show();
            this.Hide();
        }

        private void Prosmotr_Load(object sender, EventArgs e)
        {

        }

        private void zakazName_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                DataBase.GetZakazObject(dataGridView1, zakazObject1, label13, label14, zakazObject2, zakazObject3, zakazObject4, zakazObject5, zakazObject6, zakazObject7, zakazObject8, pictureBox1);    
            }
            catch
            {
                MessageBox.Show("Ошибка.");
            }
}

    }
}
